(function() {
  describe("Bootstrap Switch", function() {});

}).call(this);
